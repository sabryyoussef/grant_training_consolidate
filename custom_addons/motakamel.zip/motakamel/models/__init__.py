# -*- coding: utf-8 -*-

from . import motakamel_program
from . import motakamel_accreditation
from . import motakamel_audience
from . import motakamel_delivery
from . import motakamel_pricing
from . import motakamel_credential
from . import motakamel_marketing

